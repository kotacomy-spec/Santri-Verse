import { PieGraphSkeleton } from '@/features/overview/components/pie-graph-skeleton';

export default function Loading() {
  return <PieGraphSkeleton />;
}
